The file eye.png is modified based on an image from the Wikipedia page
on "Unsharp Mask".



